from django.apps import AppConfig


class AdministradorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'administrador_app'
