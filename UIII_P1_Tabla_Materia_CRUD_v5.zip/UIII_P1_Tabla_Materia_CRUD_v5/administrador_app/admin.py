from django.contrib import admin
from .models import Administrador
# Register your models here.
admin.site.register(Administrador)