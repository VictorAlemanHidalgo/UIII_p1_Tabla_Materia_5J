from django.apps import AppConfig


class DistribuidorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'distribuidor_app'
